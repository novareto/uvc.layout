# -*- coding: utf-8 -*-
# Copyright (c) 2007-2010 NovaReto GmbH
# cklinger@novareto.de 


import grokcore.viewlet as grok

from fanstatic import Library, Resource
from js.jquery import jquery
from megrok import resourceviewlet
from zope.interface import Interface


library = Library('uvc.layout', 'static')
